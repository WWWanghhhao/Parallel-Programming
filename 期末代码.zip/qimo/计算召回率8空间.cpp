#include <algorithm>
#include <cmath>
#include <cstdio>
#include <emmintrin.h>
#include <fstream>
#include <immintrin.h>
#include <iostream>
#include <nmmintrin.h>
#include <numeric>
#include <pmmintrin.h>
#include <queue>
#include <random>
#include <smmintrin.h>
#include <sstream>
#include <string>
#include <sys/time.h>
#include <tmmintrin.h>
#include <vector>
#include <xmmintrin.h>
using namespace std;
enum DisType {
  EucDis, // 欧氏距离
  Cosine,
  ManDis, // 曼哈顿距离

};
int dim, num;
int size = 100;
int sub_data_size = 8;
char path[1024] = "../data/sift_query.fvecs";
vector<vector<float>> ori_data;
vector<vector<vector<float>>> centroids(sub_data_size);
vector<vector<int>> clusters(1000000, vector<int>(8));

void load_ivecs_data(const char *filename, vector<vector<int>> &results,
                     int &num, int &dim) {
  ifstream in(filename, ios::binary);
  if (!in.is_open()) {
    cout << "open file error" << endl;
    exit(-1);
  }
  in.read((char *)&dim, 4);

  in.seekg(0, ios::end);
  ios::pos_type ss = in.tellg();
  size_t fsize = (size_t)ss;
  num = (int)(fsize / (dim + 1) / 4);
  results.resize(num);
  for (int i = 0; i < num; i++)
    results[i].resize(dim);
  in.seekg(0, ios::beg);
  for (size_t i = 0; i < num; i++) {
    in.seekg(4, ios::cur);
    in.read((char *)results[i].data(), dim * 4);
  }
  in.close();
}
void split_data(vector<vector<float>> &ori_data,
                vector<vector<vector<float>>> &split_data, int sub_data_size,
                int size) {
  int sub_dim = dim / sub_data_size;
  for (int i = 0; i < size; i++) {
    for (int j = 0; j < dim; j++) {
      int idx = j / sub_dim;
      split_data[idx][i].push_back(ori_data[i][j]);
    }
  }
}
float dist(const std::vector<float> &v1, const std::vector<float> &v2,
           DisType type) {
  unsigned int size = v1.size();
  __m128 sumVec = _mm_setzero_ps();
  float sum;

  switch (type) {
  case EucDis:
    for (unsigned i = 0; i < size; i += 4) {
      __m128 v1Vec = _mm_loadu_ps(&v1[i]);
      __m128 v2Vec = _mm_loadu_ps(&v2[i]);
      __m128 diff = _mm_sub_ps(v1Vec, v2Vec);
      __m128 squared = _mm_mul_ps(diff, diff);
      sumVec = _mm_add_ps(sumVec, squared);
    }
    sumVec = _mm_hadd_ps(sumVec, sumVec);
    sumVec = _mm_hadd_ps(sumVec, sumVec);

    _mm_store_ss(&sum, sumVec);
    sum = sqrt(sum);
    break;
  default:
    break;
  }
  return sum;
}

void load_centroids(vector<vector<vector<float>>> &centroid) {
  for (int i = 0; i < centroid.size(); i++) {
    string filename = "../centers" + to_string(i) + "-256-8.csv";
    ifstream file(filename);
    if (!file.is_open()) {
      cout << "fail to open" << filename << endl;
      return;
    }
    string line;
    while (getline(file, line)) {
      vector<float> row;
      stringstream ss(line);
      string cell;
      while (getline(ss, cell, ',')) {
        row.push_back(std::stof(cell));
      }
      centroid[i].push_back(row);
    }
    file.close();
  }
}
void load_clusters(vector<vector<int>> &labels) {
  for (int i = 0; i < 8; i++) {
    string filename = "../labels" + to_string(i) + "-256-8.csv";
    ifstream file(filename);
    if (!file.is_open()) {
      cout << "file to open" << filename << endl;
      return;
    }
    string line;
    int flag = 0;
    while (getline(file, line)) {
      int val = stof(line);
      labels[flag++][i] = val;
    }
    file.close();
  }
}

int find_closed(vector<float> v, vector<vector<float>> centroids) {
  float min = MAXFLOAT;
  int id = -1;
  for (int i = 0; i < centroids.size(); i++) {
    float dis = dist(v, centroids[i], EucDis);
    if (dis < min) {
      min = dis;
      id = i;
    }
  }
  return id;
}

// void encoding(int problem_size, vector<double> &times) {
//   struct timeval t1, t2;
//   double timeuse;
//   gettimeofday(&t1, NULL);
//   vector<vector<int>> id(problem_size, vector<int>(sub_data_size, -1));
//   for (int i = 0; i < problem_size; i++) {
//     vector<float> v0(ori_data[i].begin(), ori_data[i].begin() + 32);
//     vector<float> v1(ori_data[i].begin() + 32, ori_data[i].begin() + 64);
//     vector<float> v2(ori_data[i].begin() + 64, ori_data[i].begin() + 96);
//     vector<float> v3(ori_data[i].begin() + 96, ori_data[i].end());
//     id[i][0] = find_closed(v0, centroids[0]);
//     id[i][1] = find_closed(v1, centroids[1]);
//     id[i][2] = find_closed(v2, centroids[2]);
//     id[i][3] = find_closed(v3, centroids[3]);
//   }
//   gettimeofday(&t2, NULL);
//   timeuse =
//       (t2.tv_sec - t1.tv_sec) + (double)(t2.tv_usec - t1.tv_usec) / 1000000.0;
//   printf("%.6f seconds \n", timeuse);
//   times.push_back(timeuse);
// }
void load_query_ids(vector<vector<int>> &ids) {
  string file_name = "./new_res_256_8.txt";
  ifstream ifs(file_name);
  if (!ifs.is_open()) {
    cerr << "failed to open id file: " << file_name << endl;
    return;
  }
  for (int i = 0; i < ids.size(); i++) {
    string line;
    getline(ifs, line);
    istringstream iss(line);
    vector<int> id(8);
    for (int j = 0; j < 8; j++) {
      int val;
      if (!(iss >> val)) {
        cerr << "Error reading file: " << file_name << endl;
        return;
      }
      id[j] = val;
    }
    ids[i] = id;
  }
  ifs.close();
}

void compute_id_dis(vector<vector<vector<float>>> &dis,
                    vector<vector<vector<float>>> centroid) {
  for (int i = 0; i < sub_data_size; i++) {
    dis[i].resize(256);
    for (int j = 0; j < 256; j++) {
      dis[i][j].resize(j + 1);
      for (int k = 0; k < j; k++) {
        float distance = dist(centroid[i][j], centroid[i][k], EucDis);
        dis[i][j][k] = distance;
      }
    }
  }
}
vector<int> compute_topK(vector<int> &query_id, vector<vector<int>> cluster,
                         vector<vector<vector<float>>> &dis, int k) {
  priority_queue<pair<float, int>> q;
  float distance = 0;
  // ofstream ofsss("dis.txt", ios::out);
  for (int i = 0; i < cluster.size(); i++) {
    if (q.size() < k) {
      distance = 0;
      for (int j = 0; j < query_id.size(); j++) {
        if (query_id[j] == cluster[i][j]) {
          continue;
        }
        int min_id = query_id[j] < cluster[i][j] ? query_id[j] : cluster[i][j];
        int max_id = query_id[j] > cluster[i][j] ? query_id[j] : cluster[i][j];
        distance += dis[j][max_id][min_id];
      }
      q.push(pair<float, int>(distance, i));
    } else {
      distance = 0;
      for (int j = 0; j < query_id.size(); j++) {
        if (query_id[j] == cluster[i][j]) {
          continue;
        }
        int min_id = query_id[j] < cluster[i][j] ? query_id[j] : cluster[i][j];
        int max_id = query_id[j] > cluster[i][j] ? query_id[j] : cluster[i][j];
        distance += dis[j][max_id][min_id];
      }
      q.push(pair<float, int>(distance, i));
      q.pop();
    }
  }
  vector<int> ans;
  while (!q.empty()) {
    ans.emplace_back(q.top().second);
    q.pop();
  }
  reverse(ans.begin(), ans.end());
  return ans;
}

int main() {

  vector<vector<int>> id(10000);
  load_query_ids(id);
  load_centroids(centroids);
  load_clusters(clusters);
  vector<vector<vector<float>>> clusters_dis(sub_data_size);
  for (int i = 0; i < sub_data_size; i++) {
    clusters_dis[i].resize(256);
    for (int j = 0; j < 256; j++) {
      clusters_dis[i][j].resize(j + 1);
      for (int k = 0; k < j; k++) {
        float distance = dist(centroids[i][j], centroids[i][k], EucDis);
        clusters_dis[i][j][k] = distance;
        // cout << distance << " ";
      }
      // cout << endl;
    }
  }


  vector<vector<int>> right_ans(10000, vector<int>(100));
  load_ivecs_data("../data/sift_groundtruth.ivecs", right_ans, num, dim);



  struct timeval t1, t2;
  double timeuse;
  // int problem_size = i;
    ofstream ofs("召回率-256-8.txt", ios::out);
  gettimeofday(&t1, NULL);
// #pragma omp parallel for

  for (int i = 0; i < id.size(); i++) {
    // for(int i = 0;i<1000;i++){
    int cnt = 0;
    auto res = compute_topK(id[i], clusters, clusters_dis, 100);
    for (int j = 0; j < res.size(); j++) {
      if (find(right_ans[i].begin(), right_ans[i].end(), res[j]) !=
          right_ans[i].end()) {
        cnt++;
      }
    }
    // cout << cnt << endl;
    ofs << cnt << endl;
  }
  ofs.close();
  gettimeofday(&t2, NULL);
  timeuse =
      (t2.tv_sec - t1.tv_sec) + (double)(t2.tv_usec - t1.tv_usec) / 1000000.0;
  printf("%.6f seconds \n", timeuse);
  // cout << cnt << endl;

  return 0;
}
