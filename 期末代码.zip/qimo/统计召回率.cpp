#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main() {
  string filename = "召回率.txt";
  ifstream file(filename);
  if (!file.is_open()) {
    cout << "file to open" << filename << endl;
  }
  vector<int> res;
  string line;
  int flag = 0;
  while (getline(file, line)) {
    int val = stof(line);
    res.push_back(val);
  }
  file.close();

  int cnt10 = 0;
  int cnt20 = 0;
  int cnt30 = 0;
  int cnt40 = 0;
  int cnt50 = 0;
  int cnt = 0;
  for (int i = 0; i < res.size(); i++) {
    if (res[i] < 10) {
      cnt10++;
    } else if (res[i] < 20) {
      cnt20++;
    } else if (res[i] < 30) {
      cnt30++;
    } else if (res[i] < 40) {
      cnt40++;
    } else if (res[i] < 50) {
      cnt50++;
    } else {
      cnt++;
    }
  }
  cout << cnt10 << endl;
  cout << cnt20 << endl;
  cout << cnt30 << endl;
  cout << cnt40 << endl;
  cout << cnt50 << endl;
  cout << cnt << endl;
  return 0;
}