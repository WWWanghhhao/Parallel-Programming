#include <algorithm>
#include <cmath>
#include <cstdio>
#include <emmintrin.h>
#include <fstream>
#include <immintrin.h>
#include <iostream>
#include <nmmintrin.h>
#include <numeric>
#include <pmmintrin.h>
#include <queue>
#include <random>
#include <smmintrin.h>
#include <sstream>
#include <string>
#include <sys/time.h>
#include <tmmintrin.h>
#include <utility>
#include <vector>
#include <xmmintrin.h>
using namespace std;
enum DisType {
  EucDis, // 欧氏距离
  Cosine,
  ManDis, // 曼哈顿距离

};
int dim, num;

char path[1024] = "../data/sift_query.fvecs";
vector<vector<float>> ori_data;
vector<vector<float>> query_data;

void load_ivecs_data(const char *filename, vector<vector<float>> &results,
                     int &num, int &dim) {
  ifstream in(filename, ios::binary);
  if (!in.is_open()) {
    cout << "open file error" << endl;
    exit(-1);
  }
  in.read((char *)&dim, 4);

  in.seekg(0, ios::end);
  ios::pos_type ss = in.tellg();
  size_t fsize = (size_t)ss;
  num = (int)(fsize / (dim + 1) / 4);
  results.resize(num);
  for (int i = 0; i < num; i++)
    results[i].resize(dim);
  in.seekg(0, ios::beg);
  for (size_t i = 0; i < num; i++) {
    in.seekg(4, ios::cur);
    in.read((char *)results[i].data(), dim * 4);
  }
  in.close();
}
void load_ivecs_data1(const char *filename, vector<vector<int>> &results,
                      int &num, int &dim) {
  ifstream in(filename, ios::binary);
  if (!in.is_open()) {
    cout << "open file error" << endl;
    exit(-1);
  }
  in.read((char *)&dim, 4);

  in.seekg(0, ios::end);
  ios::pos_type ss = in.tellg();
  size_t fsize = (size_t)ss;
  num = (int)(fsize / (dim + 1) / 4);
  results.resize(num);
  for (int i = 0; i < num; i++)
    results[i].resize(dim);
  in.seekg(0, ios::beg);
  for (size_t i = 0; i < num; i++) {
    in.seekg(4, ios::cur);
    in.read((char *)results[i].data(), dim * 4);
  }
  in.close();
}

float dist(vector<float> v1, vector<float> v2, DisType type) {

  float sum = 0.0;
  float m1 = 0, m2 = 0;
  switch (type) {
  case EucDis:
    for (int i = 0; i < v1.size(); i++) {
      sum += (v1[i] - v2[i]) * (v1[i] - v2[i]);
    }
    sum = sqrt(sum);
    break;
  case Cosine:
    for (int i = 0; i < v1.size(); i++) {
      sum += v1[i] * v2[i];
    }
    for (int i = 0; i < v1.size(); i++) {
      m1 += v1[i] * v1[i];
      m2 += v2[i] * v2[i];
    }
    m1 = sqrt(m1);
    m2 = sqrt(m2);
    sum = sum / (m1 * m2);
    break;
  case ManDis:
    for (int i = 0; i < v1.size(); i++) {
      sum += abs(v1[i] - v2[i]);
    }
    break;
  }
  return sum;
}


int main() {

  load_ivecs_data(path, query_data, num, dim);
  char path2[1024] = "../data/sift_base.fvecs";
  int num2, dim2;
  load_ivecs_data(path2, ori_data, num2, dim2);
  cout << "num:" << num2 << endl;

  vector<vector<int>> right_ans(10000, vector<int>(100));
  load_ivecs_data1("../data/sift_groundtruth.ivecs", right_ans, num, dim);

  struct timeval t1, t2;
  double timeuse;

  gettimeofday(&t1, NULL);
// #pragma omp parallel for

  for (int i = 0; i < 100; i++) {
    float distance = 0;
    priority_queue<pair<float, int>> pq;
    for (int j = 0; j < num2; j++) {
      distance = dist(query_data[i], ori_data[j], EucDis);
      pq.push(pair<float, int>(distance, j));
      if (pq.size() > 100) {
        pq.pop();
      }
    }
    vector<int> ans;
    while (!pq.empty()) {
      ans.emplace_back(pq.top().second);
      pq.pop();
    }
    reverse(ans.begin(), ans.end());
    int cnt = 0;
    for (int j = 0; j < ans.size(); j++) {
      if (find(right_ans[i].begin(), right_ans[i].end(), ans[j]) !=
          right_ans[i].end()) {
        cnt++;
      }
    }
    // cout << "cnt:" << cnt << endl;
  }
  gettimeofday(&t2, NULL);
  timeuse =
      (t2.tv_sec - t1.tv_sec) + (double)(t2.tv_usec - t1.tv_usec) / 1000000.0;
  printf("%.6f seconds \n", timeuse);

  return 0;
}
